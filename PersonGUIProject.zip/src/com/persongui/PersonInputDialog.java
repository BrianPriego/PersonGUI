package com.persongui;

import com.persongui.model.Person;
import com.persongui.model.RegisteredPerson;
import com.persongui.model.OCCCPerson;
import oc.OCCCDate;
import oc.OCCCDateException;
import javax.swing.*;
import java.awt.*;

public class PersonInputDialog extends JDialog {
    private boolean succeeded = false;
    private Person person;
    private JTextField firstName = new JTextField(15);
    private JTextField lastName  = new JTextField(15);
    private JTextField dobField  = new JTextField("DD/MM/YYYY", 10);
    private JTextField idField   = new JTextField(15);

    public PersonInputDialog(Frame owner, String type) {
        super(owner, "Add " + type, true);
        setLayout(new GridLayout(0,2,5,5));
        add(new JLabel("First Name:")); add(firstName);
        add(new JLabel("Last  Name:")); add(lastName);
        add(new JLabel("Date of Birth:")); add(dobField);
        if (!type.equals("Person")) {
            add(new JLabel(type + " ID:")); add(idField);
        }
        JButton ok = new JButton("OK"), cancel = new JButton("Cancel");
        add(ok); add(cancel);
        ok.addActionListener(e -> onOk(type));
        cancel.addActionListener(e -> dispose());
        pack();
        setLocationRelativeTo(owner);
    }

    private void onOk(String type) {
        try {
            String[] p = dobField.getText().split("/");
            new OCCCDate(
                Integer.parseInt(p[0]),
                Integer.parseInt(p[1]),
                Integer.parseInt(p[2])
            );
            String fn = firstName.getText().trim();
            String ln = lastName.getText().trim();
            String id = idField.getText().trim();
            switch(type) {
              case "Person":
                person = new Person(fn, ln);
                break;
              case "RegisteredPerson":
                person = new RegisteredPerson(fn, ln, id);
                break;
              default:
                person = new OCCCPerson(fn, ln, id);
            }
            succeeded = true;
            dispose();
        } catch (OCCCDateException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Date!");
            dobField.setText("");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public boolean isSucceeded() { return succeeded; }
    public Person getPerson()    { return person;   }
}