package com.persongui;

import com.persongui.model.Person;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PersonManager {
    private List<Person> persons = new ArrayList<>();
    private File currentFile;
    private boolean dirty = false;

    public List<Person> getPersons() { return persons; }
    public boolean isDirty()         { return dirty; }
    public void setDirty(boolean d)  { dirty = d; }

    @SuppressWarnings("unchecked")
    public void load(File file) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            persons     = (List<Person>) in.readObject();
            currentFile = file;
            dirty       = false;
        }
    }

    public void save() throws IOException {
        if (currentFile == null) throw new IllegalStateException("No file chosen");
        saveAs(currentFile);
    }

    public void saveAs(File file) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(persons);
            currentFile = file;
            dirty       = false;
        }
    }
}