package com.persongui.model;

public class RegisteredPerson extends Person {
    private String registrationId;

    public RegisteredPerson(String firstName, String lastName, String registrationId) {
        super(firstName, lastName);
        this.registrationId = registrationId;
    }

    public String getRegistrationId() { return registrationId; }
}