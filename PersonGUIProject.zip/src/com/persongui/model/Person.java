package com.persongui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Person implements Serializable {
    private String firstName, lastName;
    private List<Person> children = new ArrayList<>();

    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName  = lastName;
    }

    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName;  }
    public List<Person> getChildren() { return children; }

    public void addChild(Person child) {
        children.add(child);
    }

    @Override
    public String toString() {
        return firstName + " " + lastName;
    }
}