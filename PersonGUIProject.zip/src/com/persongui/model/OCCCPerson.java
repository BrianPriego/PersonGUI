package com.persongui.model;

public class OCCCPerson extends Person {
    private String occcId;

    public OCCCPerson(String firstName, String lastName, String occcId) {
        super(firstName, lastName);
        this.occcId = occcId;
    }

    public String getOcccId() { return occcId; }
}