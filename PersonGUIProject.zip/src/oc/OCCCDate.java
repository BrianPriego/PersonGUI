package oc;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class OCCCDate {
    private int day, month, year;
    private GregorianCalendar calendar;

    public OCCCDate(int day, int month, int year) throws OCCCDateException {
        this.day = day;
        this.month = month;
        this.year = year;
        calendar = new GregorianCalendar(year, month - 1, day);
        if (calendar.get(Calendar.DAY_OF_MONTH) != day ||
            calendar.get(Calendar.MONTH) != (month - 1) ||
            calendar.get(Calendar.YEAR) != year) {
            throw new OCCCDateException("Invalid date input.");
        }
    }

    @Override
    public String toString() {
        return day + "/" + month + "/" + year;
    }
}